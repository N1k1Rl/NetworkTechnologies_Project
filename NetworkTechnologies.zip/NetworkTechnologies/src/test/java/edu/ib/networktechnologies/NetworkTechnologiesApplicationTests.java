package edu.ib.networktechnologies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkTechnologiesApplicationTests {

    @Test
    void contextLoads() {
    }

}
